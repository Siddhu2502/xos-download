#ifndef INTERRUPT_H
#define INTERRUPT_H

#define INT_START_PAGE		9
#define NUM_INT			8
#define PAGE_PER_INT		2
#define EXCEP_HANDLER		7
#endif
